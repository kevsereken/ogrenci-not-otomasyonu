
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using static System.Net.WebRequestMethods;


namespace OgrenciNotOtomasyonu
{
    public partial class frmGiris : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            // Buradaki t�rnak i�indeki yerleri kendi bilgilerinle doldur
            AuthSecret = "2h2vpH0S82QY4fbXL83Jd6neJlXGuD4fmSil297G",
            BasePath = "https://ogrenci-not-otomasyonu-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;
        public frmGiris()
        {
            InitializeComponent();
            client = new FireSharp.FirebaseClient(config);
            if (client == null)
            {
                MessageBox.Show("Firebase istemcisi olu�turulamad�. Ba�lant�y� kontrol edin.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

           

        }

        private async void btnGiris_Click(object sender, EventArgs e)
        {
            if (txtKullanici.Text == "" || textSifre.Text == "")
            {
                MessageBox.Show("Kullan�c� ad� ve �ifre giriniz");
                return;
            }

            var response = client.Get("kullanicilar");

            if (response.Body == "null")
            {
                MessageBox.Show("Kay�tl� kullan�c� bulunamad�");
                return;
            }

            var kullanicilar = response.ResultAs<Dictionary<string, kullanici>>();

            bool girisBasarili = false;

            foreach (var item in kullanicilar)
            {
                if (
                    item.Value.KullaniciAdi == txtKullanici.Text &&
                    item.Value.Sifre == textSifre.Text
                )
                {
                    girisBasarili = true;
                    break;
                }
            }

            if (girisBasarili)
            {
                FrmMenu menu = new FrmMenu();
                menu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullan�c� ad� veya �ifre hatal�");
            }
        }
            
        
        private void btnKayit_Click(object sender, EventArgs e)
        {
            KayitFormu frm = new KayitFormu(); // Yeni formu haf�zada olu�tur
            frm.Show(); // Ekranda g�ster
        }
    }
}
