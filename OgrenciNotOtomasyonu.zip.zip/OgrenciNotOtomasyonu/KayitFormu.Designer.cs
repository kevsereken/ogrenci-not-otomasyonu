﻿namespace OgrenciNotOtomasyonu
{
    partial class KayitFormu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            txtYeniKullanici = new TextBox();
            txtYeniSifre = new TextBox();
            btnKayıtOl = new Button();
            lblAd = new Label();
            lblSoyad = new Label();
            txtAd = new TextBox();
            txtSoyad = new TextBox();
            label5 = new Label();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(12, 134);
            label4.Name = "label4";
            label4.Size = new Size(116, 23);
            label4.TabIndex = 3;
            label4.Text = "Kullanıcı Adı:";
            // 
            // txtYeniKullanici
            // 
            txtYeniKullanici.Location = new Point(192, 134);
            txtYeniKullanici.Name = "txtYeniKullanici";
            txtYeniKullanici.Size = new Size(125, 27);
            txtYeniKullanici.TabIndex = 6;
            // 
            // txtYeniSifre
            // 
            txtYeniSifre.Location = new Point(192, 175);
            txtYeniSifre.Name = "txtYeniSifre";
            txtYeniSifre.Size = new Size(125, 27);
            txtYeniSifre.TabIndex = 7;
            // 
            // btnKayıtOl
            // 
            btnKayıtOl.Location = new Point(116, 242);
            btnKayıtOl.Name = "btnKayıtOl";
            btnKayıtOl.Size = new Size(94, 36);
            btnKayıtOl.TabIndex = 8;
            btnKayıtOl.Text = "Kayıt ol";
            btnKayıtOl.UseVisualStyleBackColor = true;
            btnKayıtOl.Click += btnKayıtOl_Click;
            // 
            // lblAd
            // 
            lblAd.AutoSize = true;
            lblAd.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lblAd.Location = new Point(12, 46);
            lblAd.Name = "lblAd";
            lblAd.Size = new Size(71, 25);
            lblAd.TabIndex = 9;
            lblAd.Text = "Adınız:";
            // 
            // lblSoyad
            // 
            lblSoyad.AutoSize = true;
            lblSoyad.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lblSoyad.Location = new Point(12, 90);
            lblSoyad.Name = "lblSoyad";
            lblSoyad.Size = new Size(99, 25);
            lblSoyad.TabIndex = 10;
            lblSoyad.Text = "Soyadınız:";
            // 
            // txtAd
            // 
            txtAd.Location = new Point(192, 44);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(125, 27);
            txtAd.TabIndex = 11;
            // 
            // txtSoyad
            // 
            txtSoyad.Location = new Point(192, 90);
            txtSoyad.Name = "txtSoyad";
            txtSoyad.Size = new Size(125, 27);
            txtSoyad.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label5.Location = new Point(12, 174);
            label5.Name = "label5";
            label5.Size = new Size(56, 25);
            label5.TabIndex = 13;
            label5.Text = "Şifre:";
            // 
            // KayitFormu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.Düzce_University_logo1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(411, 339);
            Controls.Add(label5);
            Controls.Add(txtSoyad);
            Controls.Add(txtAd);
            Controls.Add(lblSoyad);
            Controls.Add(lblAd);
            Controls.Add(btnKayıtOl);
            Controls.Add(txtYeniSifre);
            Controls.Add(txtYeniKullanici);
            Controls.Add(label4);
            DoubleBuffered = true;
            Name = "KayitFormu";
            Text = "KayitFormu";
            Load += KayitFormu_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label4;
        private TextBox txtYeniKullanici;
        private TextBox txtYeniSifre;
        private Button btnKayıtOl;
        private Label lblAd;
        private Label lblSoyad;
        private TextBox txtAd;
        private TextBox txtSoyad;
        private Label label5;
    }
}