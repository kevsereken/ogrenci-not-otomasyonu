﻿namespace OgrenciNotOtomasyonu
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            btnOgrenci = new Button();
            btnNot = new Button();
            btnDers = new Button();
            btnRapor = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnOgrenci
            // 
            btnOgrenci.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnOgrenci.Location = new Point(302, 112);
            btnOgrenci.Name = "btnOgrenci";
            btnOgrenci.Size = new Size(150, 48);
            btnOgrenci.TabIndex = 0;
            btnOgrenci.Text = "Öğrenci işlemleri";
            btnOgrenci.UseVisualStyleBackColor = true;
            btnOgrenci.Click += btnOgrenci_Click;
            // 
            // btnNot
            // 
            btnNot.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnNot.Location = new Point(304, 281);
            btnNot.Name = "btnNot";
            btnNot.Size = new Size(150, 47);
            btnNot.TabIndex = 1;
            btnNot.Text = "Not Girişi";
            btnNot.UseVisualStyleBackColor = true;
            btnNot.Click += btnNot_Click;
            // 
            // btnDers
            // 
            btnDers.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDers.Location = new Point(304, 195);
            btnDers.Name = "btnDers";
            btnDers.Size = new Size(150, 47);
            btnDers.TabIndex = 2;
            btnDers.Text = "Ders İşlemleri";
            btnDers.UseVisualStyleBackColor = true;
            btnDers.Click += btnDers_Click;
            // 
            // btnRapor
            // 
            btnRapor.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnRapor.Location = new Point(304, 366);
            btnRapor.Name = "btnRapor";
            btnRapor.Size = new Size(148, 49);
            btnRapor.TabIndex = 3;
            btnRapor.Text = "Raporlar";
            btnRapor.UseVisualStyleBackColor = true;
            btnRapor.Click += btnRapor_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Window;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(216, 48);
            label1.Name = "label1";
            label1.Size = new Size(338, 25);
            label1.TabIndex = 4;
            label1.Text = "Lütfen yapmak istediğiniz işlemi seçin.";
            // 
            // FrmMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.Düzce_University_logo1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(btnRapor);
            Controls.Add(btnDers);
            Controls.Add(btnNot);
            Controls.Add(btnOgrenci);
            DoubleBuffered = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FrmMenu";
            Text = "Menü Ekranı";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnOgrenci;
        private Button btnNot;
        private Button btnDers;
        private Button btnRapor;
        private Label label1;
    }
}