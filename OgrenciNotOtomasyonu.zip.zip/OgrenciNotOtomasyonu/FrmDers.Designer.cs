﻿namespace OgrenciNotOtomasyonu
{
    partial class FrmDers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDers));
            lblDersAd = new Label();
            lblKod = new Label();
            txtDersAd = new TextBox();
            txtKod = new TextBox();
            btnEkle = new Button();
            btnSil = new Button();
            btnGüncelle = new Button();
            lstDers = new ListBox();
            SuspendLayout();
            // 
            // lblDersAd
            // 
            lblDersAd.AutoSize = true;
            lblDersAd.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblDersAd.Location = new Point(205, 81);
            lblDersAd.Name = "lblDersAd";
            lblDersAd.Size = new Size(84, 23);
            lblDersAd.TabIndex = 0;
            lblDersAd.Text = "Ders Adı:";
            // 
            // lblKod
            // 
            lblKod.AutoSize = true;
            lblKod.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblKod.Location = new Point(205, 130);
            lblKod.Name = "lblKod";
            lblKod.Size = new Size(98, 23);
            lblKod.TabIndex = 1;
            lblKod.Text = "Ders Kodu:";
            // 
            // txtDersAd
            // 
            txtDersAd.Location = new Point(339, 77);
            txtDersAd.Name = "txtDersAd";
            txtDersAd.Size = new Size(125, 27);
            txtDersAd.TabIndex = 2;
            // 
            // txtKod
            // 
            txtKod.Location = new Point(339, 126);
            txtKod.Name = "txtKod";
            txtKod.Size = new Size(125, 27);
            txtKod.TabIndex = 3;
            // 
            // btnEkle
            // 
            btnEkle.Font = new Font("Segoe UI", 9F);
            btnEkle.Location = new Point(311, 200);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 29);
            btnEkle.TabIndex = 4;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnSil
            // 
            btnSil.Font = new Font("Segoe UI", 9F);
            btnSil.Location = new Point(481, 200);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(94, 29);
            btnSil.TabIndex = 5;
            btnSil.Text = "SİL";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnGüncelle
            // 
            btnGüncelle.Font = new Font("Segoe UI", 9F);
            btnGüncelle.Location = new Point(140, 200);
            btnGüncelle.Name = "btnGüncelle";
            btnGüncelle.Size = new Size(103, 29);
            btnGüncelle.TabIndex = 6;
            btnGüncelle.Text = "GÜNCELLE";
            btnGüncelle.UseVisualStyleBackColor = true;
            btnGüncelle.Click += btnGüncelle_Click;
            // 
            // lstDers
            // 
            lstDers.FormattingEnabled = true;
            lstDers.Location = new Point(173, 257);
            lstDers.Name = "lstDers";
            lstDers.Size = new Size(371, 204);
            lstDers.TabIndex = 7;
            lstDers.SelectedIndexChanged += lstDers_SelectedIndexChanged;
            // 
            // FrmDers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.Düzce_University_logo1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(757, 463);
            Controls.Add(lstDers);
            Controls.Add(btnGüncelle);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(txtKod);
            Controls.Add(txtDersAd);
            Controls.Add(lblKod);
            Controls.Add(lblDersAd);
            DoubleBuffered = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FrmDers";
            Text = "Ders İşlemleri";
            Load += FrmDers_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblDersAd;
        private Label lblKod;
        private TextBox txtDersAd;
        private TextBox txtKod;
        private Button btnEkle;
        private Button btnSil;
        private Button btnGüncelle;
        private ListBox lstDers;
    }
}