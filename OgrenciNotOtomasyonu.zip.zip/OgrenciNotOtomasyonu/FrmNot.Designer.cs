﻿
namespace OgrenciNotOtomasyonu
{
    partial class FrmNot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmNot));
            lblOgrenci = new Label();
            lblDers = new Label();
            lblVize = new Label();
            lblFinal = new Label();
            txtVize = new TextBox();
            txtFinal = new TextBox();
            btnEkle = new Button();
            lstNotlar = new ListBox();
            cmbDers = new ComboBox();
            cmbOgrenci = new ComboBox();
            btnNotGüncelle = new Button();
            SuspendLayout();
            // 
            // lblOgrenci
            // 
            lblOgrenci.AutoSize = true;
            lblOgrenci.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblOgrenci.Location = new Point(28, 41);
            lblOgrenci.Name = "lblOgrenci";
            lblOgrenci.Size = new Size(78, 23);
            lblOgrenci.TabIndex = 0;
            lblOgrenci.Text = "Öğrenci:";
            // 
            // lblDers
            // 
            lblDers.AutoSize = true;
            lblDers.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblDers.Location = new Point(28, 87);
            lblDers.Name = "lblDers";
            lblDers.Size = new Size(84, 23);
            lblDers.TabIndex = 1;
            lblDers.Text = "Ders Adı:";
            // 
            // lblVize
            // 
            lblVize.AutoSize = true;
            lblVize.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblVize.Location = new Point(28, 135);
            lblVize.Name = "lblVize";
            lblVize.Size = new Size(93, 23);
            lblVize.TabIndex = 2;
            lblVize.Text = "Vize Notu:";
            // 
            // lblFinal
            // 
            lblFinal.AutoSize = true;
            lblFinal.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblFinal.Location = new Point(28, 185);
            lblFinal.Name = "lblFinal";
            lblFinal.Size = new Size(98, 23);
            lblFinal.TabIndex = 3;
            lblFinal.Text = "Final Notu:";
            // 
            // txtVize
            // 
            txtVize.Location = new Point(146, 131);
            txtVize.Name = "txtVize";
            txtVize.Size = new Size(151, 27);
            txtVize.TabIndex = 6;
            // 
            // txtFinal
            // 
            txtFinal.Location = new Point(146, 181);
            txtFinal.Name = "txtFinal";
            txtFinal.Size = new Size(151, 27);
            txtFinal.TabIndex = 7;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(238, 249);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(156, 38);
            btnEkle.TabIndex = 8;
            btnEkle.Text = "Notu Kaydet";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // lstNotlar
            // 
            lstNotlar.AllowDrop = true;
            lstNotlar.Dock = DockStyle.Right;
            lstNotlar.FormattingEnabled = true;
            lstNotlar.Location = new Point(457, 0);
            lstNotlar.Name = "lstNotlar";
            lstNotlar.Size = new Size(442, 477);
            lstNotlar.TabIndex = 9;
            lstNotlar.SelectedIndexChanged += lstNotlar_SelectedIndexChanged;
            // 
            // cmbDers
            // 
            cmbDers.FormattingEnabled = true;
            cmbDers.Location = new Point(146, 82);
            cmbDers.Name = "cmbDers";
            cmbDers.Size = new Size(248, 28);
            cmbDers.TabIndex = 10;
            // 
            // cmbOgrenci
            // 
            cmbOgrenci.FormattingEnabled = true;
            cmbOgrenci.Location = new Point(146, 36);
            cmbOgrenci.Name = "cmbOgrenci";
            cmbOgrenci.Size = new Size(248, 28);
            cmbOgrenci.TabIndex = 11;
            // 
            // btnNotGüncelle
            // 
            btnNotGüncelle.Location = new Point(28, 249);
            btnNotGüncelle.Name = "btnNotGüncelle";
            btnNotGüncelle.Size = new Size(156, 38);
            btnNotGüncelle.TabIndex = 12;
            btnNotGüncelle.Text = "Güncelle";
            btnNotGüncelle.UseVisualStyleBackColor = true;
            btnNotGüncelle.Click += btnNotGüncelle_Click;
            // 
            // FrmNot
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.Düzce_University_logo1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(899, 477);
            Controls.Add(btnNotGüncelle);
            Controls.Add(cmbOgrenci);
            Controls.Add(cmbDers);
            Controls.Add(lstNotlar);
            Controls.Add(btnEkle);
            Controls.Add(txtFinal);
            Controls.Add(txtVize);
            Controls.Add(lblFinal);
            Controls.Add(lblVize);
            Controls.Add(lblDers);
            Controls.Add(lblOgrenci);
            DoubleBuffered = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FrmNot";
            Text = "Not Giriş Ekranı";
            Load += FrmNot_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private void lstNotlar_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        #endregion

        private Label lblOgrenci;
        private Label lblDers;
        private Label lblVize;
        private Label lblFinal;
        private TextBox txtOgrenci;
        private TextBox txtDers;
        private TextBox txtVize;
        private TextBox txtFinal;
        private Button btnEkle;
        private ListBox lstNotlar;
        private ComboBox cmbDers;
        private ComboBox cmbOgrenci;
        private Button btnNotGüncelle;
    }
}