﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;

namespace OgrenciNotOtomasyonu
{
    public partial class FrmOgrenci : Form
    {
        IFirebaseClient client;

        public FrmOgrenci()
        {
            InitializeComponent();
            FirebaseBaglan();
        }
        void FirebaseBaglan()
        {

            IFirebaseConfig config = new FirebaseConfig
            {

                AuthSecret = "2h2vpH0S82QY4fbXL83Jd6neJlXGuD4fmSil297G",
                BasePath = "https://ogrenci-not-otomasyonu-default-rtdb.firebaseio.com/"
            };

            client = new FirebaseClient(config);
        }


        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "" || txtSoyad.Text == "" || txtNo.Text == "")
            {
                MessageBox.Show("Lütfen tüm alanları doldurun");
                return;
            }

            string numara = txtNo.Text.Trim(); // 🔴 KRİTİK SATIR

            var kontrol = client.Get("ogrenciler/" + numara);

            if (kontrol.Body != "null")
            {
                MessageBox.Show("Bu numarada zaten bir öğrenci var");
                return;
            }

            Ogrenci ogr = new Ogrenci()
            {
                Ad = txtAd.Text,
                Soyad = txtSoyad.Text
            };

            client.Set("ogrenciler/" + numara, ogr);

            MessageBox.Show("Öğrenci eklendi");

            Listele();
            Temizle();
        }




        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtNo.Text == "")
            {
                MessageBox.Show("Silinecek öğrenci numarasını giriniz");
                return;
            }

            DialogResult dr = MessageBox.Show(
                "Bu öğrenciyi silmek istiyor musunuz?",
                "Uyarı",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (dr == DialogResult.No)
                return;

            client.Delete("ogrenciler/" + txtNo.Text);

            MessageBox.Show("Öğrenci silindi");

            Listele();
            Temizle();
        }

        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            if (txtNo.Text == "")
            {
                MessageBox.Show("Güncellenecek öğrenci numarasını giriniz");
                return;
            }

            Ogrenci ogr = new Ogrenci()
            {
                Ad = txtAd.Text,
                Soyad = txtSoyad.Text
            };

            client.Update("ogrenciler/" + txtNo.Text, ogr);

            MessageBox.Show("Öğrenci güncellendi");

            Listele();
            Temizle();
        }


        void Listele()
        {
            lstOgrenci.Items.Clear();

            var response = client.Get("ogrenciler");

            if (response.Body == "null")
                return;

            var ogrenciler = response.ResultAs<Dictionary<string, Ogrenci>>();

            foreach (var item in ogrenciler)
            {
                lstOgrenci.Items.Add(
                    item.Key + " - " + item.Value.Ad + " " + item.Value.Soyad
                );
            }
        }

        private void lstOgrenci_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstOgrenci.SelectedItem == null)
                return;

            string secilen = lstOgrenci.SelectedItem.ToString();
            string numara = secilen.Split('-')[0].Trim();

            var response = client.Get("ogrenciler/" + numara);
            Ogrenci ogr = response.ResultAs<Ogrenci>();

            txtNo.Text = numara;
            txtAd.Text = ogr.Ad;
            txtSoyad.Text = ogr.Soyad;
        }

        private void FrmOgrenci_Load(object sender, EventArgs e)
        {
            Listele();
        }
        void Temizle()
        {
            txtAd.Clear();
            txtSoyad.Clear();
            txtNo.Clear();
        }

        private void txtNo_KeyPress(object sender, KeyPressEventArgs e)
        
        {
            // Rakamlar ve kontrol tuşlarına (backspace vb.) izin ver
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}



