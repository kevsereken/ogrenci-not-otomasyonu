﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;

namespace OgrenciNotOtomasyonu
{
    public partial class FrmNot : Form
    {
        IFirebaseClient client;
        public FrmNot()
        {
            InitializeComponent();
            FirebaseBaglan();
        }
        void FirebaseBaglan()
        {

            IFirebaseConfig config = new FirebaseConfig
            {

                AuthSecret = "2h2vpH0S82QY4fbXL83Jd6neJlXGuD4fmSil297G",
                BasePath = "https://ogrenci-not-otomasyonu-default-rtdb.firebaseio.com/"
            };

            client = new FirebaseClient(config);
        }


        void OgrenciGetir()
        {
            var response = client.Get("ogrenciler");

            if (response.Body == "null")
                return;

            var ogrenciler = response.ResultAs<Dictionary<string, Ogrenci>>();

            foreach (var item in ogrenciler)
            {
                cmbOgrenci.Items.Add(
                    item.Key + " - " + item.Value.Ad + " " + item.Value.Soyad
                );
            }
        }

        void DersGetir()
        {
            var response = client.Get("dersler");

            if (response.Body == "null")
                return;

            var dersler = response.ResultAs<Dictionary<string, Ders>>();

            foreach (var item in dersler)
            {
                cmbDers.Items.Add(
                    item.Key + " - " + item.Value.DersAdi
                );
            }
        }




        void NotListele()
        {
            

            lstNotlar.Items.Clear();

            var response = client.Get("notlar");

            if (response.Body == "null")
                return;

            var notlar = response.ResultAs<Dictionary<string, NotBilgisi>>();

            foreach (var item in notlar)
            {
                lstNotlar.Items.Add(
            item.Value.OgrenciAd + " | " +
            item.Value.DersAd + " | " +
            "Ort: " + item.Value.ortalama.ToString("0.00") +
            " | " + item.Value.HarfNotu);
            }
        }



        private void FrmNot_Load(object sender, EventArgs e)
        {
            OgrenciGetir();
            DersGetir();
            NotListele();

            lstNotlar.DrawMode = DrawMode.OwnerDrawFixed;
            lstNotlar.DrawItem += lstNotlar_DrawItem;
            NotListele();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (cmbOgrenci.SelectedItem == null ||
        cmbDers.SelectedItem == null ||
        txtVize.Text == "" ||
        txtFinal.Text == "")
            {
                MessageBox.Show("Lütfen tüm alanları doldurun");
                return;
            }

            int vize = int.Parse(txtVize.Text);
            int final = int.Parse(txtFinal.Text);

            double ortalama = (vize * 0.4) + (final * 0.6);
            string harfNotu = HarfNotuHesapla(ortalama);

            string ogrSecilen = cmbOgrenci.SelectedItem.ToString();
            string dersSecilen = cmbDers.SelectedItem.ToString();

            string ogrNo = ogrSecilen.Split('-')[0].Trim();
            string ogrAd = ogrSecilen.Split('-')[1].Trim();

            string dersKodu = dersSecilen.Split('-')[0].Trim();
            string dersAdi = dersSecilen.Split('-')[1].Trim();

            string key = ogrNo + "_" + dersKodu;

            var kontrol = client.Get("notlar/" + key);

            if (kontrol.Body != "null")
            {
                MessageBox.Show("Bu öğrenci için bu dersin notu zaten girilmiş");
                return;
            }

            NotBilgisi yeniNot = new NotBilgisi()
            {
                OgrenciNo = ogrNo,
                OgrenciAd = ogrAd,
                DersKodu = dersKodu,
                DersAd = dersAdi,
                Vize = vize,
                Final = final,
                ortalama = ortalama,
                HarfNotu = harfNotu
            };

            client.Set("notlar/" + key, yeniNot);

            MessageBox.Show("Not kaydedildi");

            NotListele();
            Temizle();
        }

        string HarfNotuHesapla(double ortalama)
        {
            if (ortalama >= 90) return "AA";
            if (ortalama >= 85) return "BA";
            if (ortalama >= 80) return "BB";
            if (ortalama >= 70) return "CB";
            if (ortalama >= 60) return "CC";
            if (ortalama >= 55) return "DC";
            if (ortalama >= 50) return "DD";
            if (ortalama >= 40) return "FD";
            return "FF";
        }

        void Temizle()
        {
            cmbOgrenci.SelectedItem = null;
            cmbDers.SelectedItem = null;
            txtVize.Clear();
            txtFinal.Clear();
        }

        private void lstNotlar_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            e.DrawBackground();

            string metin = lstNotlar.Items[e.Index].ToString();

            Brush yaziRengi = Brushes.Black;

            if (metin.Contains("FF"))
                yaziRengi = Brushes.Red;

            e.Graphics.DrawString(
                metin,
                e.Font,
                yaziRengi,
                e.Bounds
            );

            e.DrawFocusRectangle();
        }

        private void btnNotGüncelle_Click(object sender, EventArgs e)
        {
            if (cmbOgrenci.SelectedItem == null ||
       cmbDers.SelectedItem == null ||
       txtVize.Text == "" ||
       txtFinal.Text == "")
            {
                MessageBox.Show("Lütfen tüm alanları doldurun");
                return;
            }

            int vize = int.Parse(txtVize.Text);
            int final = int.Parse(txtFinal.Text);

            double ortalama = (vize * 0.4) + (final * 0.6);
            string harfNotu = HarfNotuHesapla(ortalama);

            string ogrSecilen = cmbOgrenci.SelectedItem.ToString();
            string dersSecilen = cmbDers.SelectedItem.ToString();

            string ogrNo = ogrSecilen.Split('-')[0].Trim();
            string ogrAd = ogrSecilen.Split('-')[1].Trim();

            string dersKodu = dersSecilen.Split('-')[0].Trim();
            string dersAdi = dersSecilen.Split('-')[1].Trim();

            string key = ogrNo + "_" + dersKodu;

            var kontrol = client.Get("notlar/" + key);

            if (kontrol.Body == "null")
            {
                MessageBox.Show("Güncellenecek not bulunamadı");
                return;
            }

            NotBilgisi guncelNot = new NotBilgisi()
            {
                OgrenciNo = ogrNo,
                OgrenciAd = ogrAd,
                DersKodu = dersKodu,
                DersAd = dersAdi,
                Vize = vize,
                Final = final,
                ortalama = ortalama,
                HarfNotu = harfNotu
            };

            client.Update("notlar/" + key, guncelNot);

            MessageBox.Show("Not güncellendi");

            NotListele();
            Temizle();
        }
    }
}

