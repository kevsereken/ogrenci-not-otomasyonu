﻿namespace OgrenciNotOtomasyonu
{
    partial class frmGiris
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGiris));
            lblKullanici = new Label();
            lblSifre = new Label();
            txtKullanici = new TextBox();
            textSifre = new TextBox();
            btnGiris = new Button();
            btnKayit = new Button();
            SuspendLayout();
            // 
            // lblKullanici
            // 
            lblKullanici.AutoSize = true;
            lblKullanici.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold);
            lblKullanici.Location = new Point(222, 139);
            lblKullanici.Name = "lblKullanici";
            lblKullanici.Size = new Size(121, 25);
            lblKullanici.TabIndex = 0;
            lblKullanici.Text = "Kullanıcı adı:";
            // 
            // lblSifre
            // 
            lblSifre.AutoSize = true;
            lblSifre.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold);
            lblSifre.Location = new Point(252, 187);
            lblSifre.Name = "lblSifre";
            lblSifre.Size = new Size(56, 25);
            lblSifre.TabIndex = 1;
            lblSifre.Text = "Şifre:";
            // 
            // txtKullanici
            // 
            txtKullanici.Font = new Font("Segoe UI", 10.8F);
            txtKullanici.Location = new Point(377, 140);
            txtKullanici.Name = "txtKullanici";
            txtKullanici.Size = new Size(150, 31);
            txtKullanici.TabIndex = 2;
            // 
            // textSifre
            // 
            textSifre.Font = new Font("Segoe UI", 10.8F);
            textSifre.Location = new Point(377, 188);
            textSifre.Name = "textSifre";
            textSifre.PasswordChar = '*';
            textSifre.Size = new Size(150, 31);
            textSifre.TabIndex = 3;
            // 
            // btnGiris
            // 
            btnGiris.BackgroundImage = Properties.Resources.Düzce_University_logo_svg;
            btnGiris.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnGiris.Location = new Point(325, 247);
            btnGiris.Name = "btnGiris";
            btnGiris.Size = new Size(103, 35);
            btnGiris.TabIndex = 4;
            btnGiris.Text = "GİRİŞ";
            btnGiris.UseVisualStyleBackColor = true;
            btnGiris.Click += btnGiris_Click;
            // 
            // btnKayit
            // 
            btnKayit.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnKayit.BackgroundImage = Properties.Resources.Ekran_görüntüsü_2025_12_16_162416;
            btnKayit.BackgroundImageLayout = ImageLayout.None;
            btnKayit.Location = new Point(622, 12);
            btnKayit.Name = "btnKayit";
            btnKayit.Size = new Size(161, 54);
            btnKayit.TabIndex = 5;
            btnKayit.Text = "Kayıt olmak için tıklayınız.";
            btnKayit.UseVisualStyleBackColor = true;
            btnKayit.Click += btnKayit_Click;
            // 
            // frmGiris
            // 
            AccessibleName = "";
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.Düzce_University_logo1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(795, 451);
            Controls.Add(btnKayit);
            Controls.Add(btnGiris);
            Controls.Add(textSifre);
            Controls.Add(txtKullanici);
            Controls.Add(lblSifre);
            Controls.Add(lblKullanici);
            DoubleBuffered = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "frmGiris";
            Text = "Giriş Ekranı";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblKullanici;
        private Label lblSifre;
        private TextBox txtKullanici;
        private TextBox textSifre;
        private Button btnGiris;
        private Button btnKayit;
    }
}
