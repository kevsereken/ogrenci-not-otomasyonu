﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OgrenciNotOtomasyonu.NotHesaplama
{
    public class StandartNotHesaplayici : NotHesaplayici
    {
        public override double OrtalamaHesapla(int vize, int final)    // kalıtımı ekledim
        {
            return vize * 0.4 + final * 0.6;
        }

        public override string HarfNotuHesapla(double ortalama)
        {
            if (ortalama >= 90) return "AA";
            if (ortalama >= 85) return "BA";
            if (ortalama >= 80) return "BB";
            if (ortalama >= 70) return "CB";
            if (ortalama >= 60) return "CC";
            if (ortalama >= 55) return "DC";
            if (ortalama >= 50) return "DD";
            if (ortalama >= 40) return "FD";
            return "FF";
        }
    }
}
