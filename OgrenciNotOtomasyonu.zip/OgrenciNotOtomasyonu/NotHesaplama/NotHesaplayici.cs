﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OgrenciNotOtomasyonu.NotHesaplama
{
    public abstract class NotHesaplayici         // soyutlamayı kullandım
    {                
            public abstract double OrtalamaHesapla(int vize, int final);
            public abstract string HarfNotuHesapla(double ortalama);        
    }
}
