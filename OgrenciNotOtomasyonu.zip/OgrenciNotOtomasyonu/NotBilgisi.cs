﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OgrenciNotOtomasyonu
{
    internal class NotBilgisi
    {
        public string OgrenciNo { get; set; }
        public string OgrenciAd { get; set; }
        public string DersKodu { get; set; }
        public string DersAd { get; set; }
        public int Vize { get; set; }
        public int Final { get; set; }
        public double ortalama { get; set; }
        public string HarfNotu { get; set; }
    }
}
