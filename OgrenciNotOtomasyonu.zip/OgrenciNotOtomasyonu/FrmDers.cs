﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OgrenciNotOtomasyonu
{
    public partial class FrmDers : Form
    {

        IFirebaseClient client;

        public FrmDers()
        {
            InitializeComponent();
            FirebaseBaglan();
        }

        void FirebaseBaglan()
        {
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "2h2vpH0S82QY4fbXL83Jd6neJlXGuD4fmSil297G",
                BasePath = "https://ogrenci-not-otomasyonu-default-rtdb.firebaseio.com/"
            };

            client = new FirebaseClient(config);
        }





        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtDersAd.Text == "" || txtKod.Text == "")
            {
                MessageBox.Show("Lütfen tüm alanları doldurun");
                return;
            }

            string kod = txtKod.Text.Trim();

            var kontrol = client.Get("dersler/" + kod);

            if (kontrol.Body != "null")
            {
                MessageBox.Show("Bu ders kodu zaten kayıtlı");
                return;
            }

            Ders ders = new Ders()
            {
                DersAdi = txtDersAd.Text
            };

            client.Set("dersler/" + kod, ders);

            MessageBox.Show("Ders eklendi");

            Listele();
            Temizle();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtKod.Text == "")
            {
                MessageBox.Show("Silinecek ders kodunu giriniz");
                return;
            }

            DialogResult dr = MessageBox.Show(
                "Bu dersi silmek istiyor musunuz?",
                "Uyarı",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (dr == DialogResult.No)
                return;

            client.Delete("dersler/" + txtKod.Text.Trim());

            MessageBox.Show("Ders silindi");

            Listele();
            Temizle();
        }

        private void btnGüncelle_Click(object sender, EventArgs e)
        {
            if (txtKod.Text == "")
            {
                MessageBox.Show("Güncellenecek ders kodunu giriniz");
                return;
            }

            Ders ders = new Ders()
            {
                DersAdi = txtDersAd.Text
            };

            client.Update("dersler/" + txtKod.Text.Trim(), ders);

            MessageBox.Show("Ders güncellendi");

            Listele();
            Temizle();
        }

        private void lstDers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDers.SelectedItem == null)
                return;

            string secilen = lstDers.SelectedItem.ToString();
            string kod = secilen.Split('-')[0].Trim();

            var response = client.Get("dersler/" + kod);
            Ders ders = response.ResultAs<Ders>();

            txtKod.Text = kod;
            txtDersAd.Text = ders.DersAdi;
        }
        void Listele()
        {
            lstDers.Items.Clear();

            FirebaseResponse response;

            try
            {
                response = client.Get("dersler");
            }
            catch
            {
                MessageBox.Show("Firebase bağlantısı başarısız");
                return;
            }

            if (response.Body == "null")
                return;

            var dersler = response.ResultAs<Dictionary<string, Ders>>();

            if (dersler == null)
                return;

            foreach (var item in dersler)
            {
                lstDers.Items.Add(item.Key + " - " + item.Value.DersAdi);
            }
        }
        private void FrmDers_Load(object sender, EventArgs e)
        {
            Listele();
        }


     
       
        void Temizle()
        {
            txtDersAd.Clear();
            txtKod.Clear();
        }

    }
}
