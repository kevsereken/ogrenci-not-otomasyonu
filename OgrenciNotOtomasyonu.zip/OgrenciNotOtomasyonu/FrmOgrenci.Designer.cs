﻿namespace OgrenciNotOtomasyonu
{
    partial class FrmOgrenci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmOgrenci));
            lblAd = new Label();
            lblSoyad = new Label();
            txtNo = new TextBox();
            txtNumara = new Label();
            btnEkle = new Button();
            btnSil = new Button();
            btnGüncelle = new Button();
            lstOgrenci = new ListBox();
            txtAd = new TextBox();
            txtSoyad = new TextBox();
            SuspendLayout();
            // 
            // lblAd
            // 
            lblAd.AutoSize = true;
            lblAd.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblAd.Location = new Point(183, 87);
            lblAd.Name = "lblAd";
            lblAd.Size = new Size(38, 23);
            lblAd.TabIndex = 0;
            lblAd.Text = "Ad:";
            // 
            // lblSoyad
            // 
            lblSoyad.AutoSize = true;
            lblSoyad.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            lblSoyad.Location = new Point(183, 131);
            lblSoyad.Name = "lblSoyad";
            lblSoyad.Size = new Size(64, 23);
            lblSoyad.TabIndex = 1;
            lblSoyad.Text = "Soyad:";
            // 
            // txtNo
            // 
            txtNo.Location = new Point(285, 173);
            txtNo.Name = "txtNo";
            txtNo.Size = new Size(125, 27);
            txtNo.TabIndex = 4;
            txtNo.KeyPress += txtNo_KeyPress;
            // 
            // txtNumara
            // 
            txtNumara.AutoSize = true;
            txtNumara.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold);
            txtNumara.Location = new Point(183, 177);
            txtNumara.Name = "txtNumara";
            txtNumara.Size = new Size(79, 23);
            txtNumara.TabIndex = 5;
            txtNumara.Text = "Numara:";
            // 
            // btnEkle
            // 
            btnEkle.Font = new Font("Segoe UI", 9F);
            btnEkle.Location = new Point(476, 83);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 27);
            btnEkle.TabIndex = 6;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnSil
            // 
            btnSil.Font = new Font("Segoe UI", 9F);
            btnSil.Location = new Point(476, 125);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(94, 29);
            btnSil.TabIndex = 7;
            btnSil.Text = "SİL";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnGüncelle
            // 
            btnGüncelle.Font = new Font("Segoe UI", 9F);
            btnGüncelle.Location = new Point(476, 173);
            btnGüncelle.Name = "btnGüncelle";
            btnGüncelle.Size = new Size(94, 27);
            btnGüncelle.TabIndex = 8;
            btnGüncelle.Text = "GÜNCELLE";
            btnGüncelle.UseVisualStyleBackColor = true;
            btnGüncelle.Click += btnGüncelle_Click;
            // 
            // lstOgrenci
            // 
            lstOgrenci.BackColor = SystemColors.Window;
            lstOgrenci.FormattingEnabled = true;
            lstOgrenci.Location = new Point(198, 234);
            lstOgrenci.Name = "lstOgrenci";
            lstOgrenci.Size = new Size(357, 204);
            lstOgrenci.TabIndex = 9;
            lstOgrenci.SelectedIndexChanged += lstOgrenci_SelectedIndexChanged;
            // 
            // txtAd
            // 
            txtAd.Location = new Point(285, 87);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(125, 27);
            txtAd.TabIndex = 10;
            // 
            // txtSoyad
            // 
            txtSoyad.Location = new Point(285, 131);
            txtSoyad.Name = "txtSoyad";
            txtSoyad.Size = new Size(125, 27);
            txtSoyad.TabIndex = 11;
            // 
            // FrmOgrenci
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.Düzce_University_logo1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(766, 462);
            Controls.Add(txtSoyad);
            Controls.Add(txtAd);
            Controls.Add(lstOgrenci);
            Controls.Add(btnGüncelle);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(txtNumara);
            Controls.Add(txtNo);
            Controls.Add(lblSoyad);
            Controls.Add(lblAd);
            DoubleBuffered = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FrmOgrenci";
            Text = "Öğrenci İşlemleri";
            Load += FrmOgrenci_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAd;
        private Label lblSoyad;
        private TextBox txtNo;
        private Label txtNumara;
        private Button btnEkle;
        private Button btnSil;
        private Button btnGüncelle;
        private ListBox lstOgrenci;
        private TextBox txtAd;
        private TextBox txtSoyad;
    }
}