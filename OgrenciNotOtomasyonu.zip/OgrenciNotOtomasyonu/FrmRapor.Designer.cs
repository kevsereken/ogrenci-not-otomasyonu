﻿namespace OgrenciNotOtomasyonu
{
    partial class Raporlama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstRapor = new ListBox();
            btnRaporOluştur = new Button();
            lstDersAnaliz = new ListBox();
            btnDersAnaliz = new Button();
            SuspendLayout();
            // 
            // lstRapor
            // 
            lstRapor.FormattingEnabled = true;
            lstRapor.Location = new Point(0, 40);
            lstRapor.Name = "lstRapor";
            lstRapor.Size = new Size(480, 484);
            lstRapor.TabIndex = 0;
            lstRapor.SelectedIndexChanged += lstRapor_SelectedIndexChanged;
            // 
            // btnRaporOluştur
            // 
            btnRaporOluştur.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnRaporOluştur.Location = new Point(0, 0);
            btnRaporOluştur.Name = "btnRaporOluştur";
            btnRaporOluştur.Size = new Size(480, 41);
            btnRaporOluştur.TabIndex = 1;
            btnRaporOluştur.Text = "Rapor oluşturmak için tıklayınız.";
            btnRaporOluştur.UseVisualStyleBackColor = true;
            btnRaporOluştur.Click += btnRaporOluştur_Click;
            // 
            // lstDersAnaliz
            // 
            lstDersAnaliz.FormattingEnabled = true;
            lstDersAnaliz.Location = new Point(478, 40);
            lstDersAnaliz.Name = "lstDersAnaliz";
            lstDersAnaliz.Size = new Size(469, 484);
            lstDersAnaliz.TabIndex = 2;
            // 
            // btnDersAnaliz
            // 
            btnDersAnaliz.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnDersAnaliz.Location = new Point(478, -4);
            btnDersAnaliz.Name = "btnDersAnaliz";
            btnDersAnaliz.Size = new Size(469, 45);
            btnDersAnaliz.TabIndex = 3;
            btnDersAnaliz.Text = "Ders analizi için tıklayınız.";
            btnDersAnaliz.UseVisualStyleBackColor = true;
            btnDersAnaliz.Click += btnDersAnaliz_Click;
            // 
            // Raporlama
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.Düzce_University_logo1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(945, 513);
            Controls.Add(btnDersAnaliz);
            Controls.Add(lstDersAnaliz);
            Controls.Add(btnRaporOluştur);
            Controls.Add(lstRapor);
            DoubleBuffered = true;
            Name = "Raporlama";
            Text = "Raporlama";
            Load += Raporlama_Load;
            ResumeLayout(false);
        }

        #endregion

        private ListBox lstRapor;
        private Button btnRaporOluştur;
        private ListBox lstDersAnaliz;
        private Button btnDersAnaliz;
    }
}