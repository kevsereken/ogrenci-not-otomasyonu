﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OgrenciNotOtomasyonu
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void btnOgrenci_Click(object sender, EventArgs e)
        {
            FrmOgrenci ogrenci = new FrmOgrenci();
            ogrenci.Show();
        }

        private void btnDers_Click(object sender, EventArgs e)
        {
            FrmDers ders = new FrmDers();
            ders.Show();
        }

        private void btnNot_Click(object sender, EventArgs e)
        {
            FrmNot not = new FrmNot();
            not.Show();
        }

        private void btnRapor_Click(object sender, EventArgs e)
        {
            Raporlama rapor = new Raporlama();
            rapor.Show();
        }
    }
}
