﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OgrenciNotOtomasyonu
{
    public partial class KayitFormu : Form
    {

        IFirebaseClient client;



        public KayitFormu()
        {
            InitializeComponent();
            FirebaseBaglan();
        }
        void FirebaseBaglan()
        {

            IFirebaseConfig config = new FirebaseConfig
            {

                AuthSecret = "2h2vpH0S82QY4fbXL83Jd6neJlXGuD4fmSil297G",
                BasePath = "https://ogrenci-not-otomasyonu-default-rtdb.firebaseio.com/"
            };

            client = new FirebaseClient(config);
        }

        private void KayitFormu_Load(object sender, EventArgs e)
        {

        }

        private async Task btnKayıtOl_Async(object sender, EventArgs e)
        {

           
        }

        private void btnKayıtOl_Click(object sender, EventArgs e)
        {
            if (
        txtAd.Text == "" ||
        txtSoyad.Text == "" ||
        txtYeniKullanici.Text == "" ||
        txtYeniSifre.Text == ""
    )
            {
                MessageBox.Show("Lütfen tüm alanları doldurun");
                return;
            }

            var response = client.Get("kullanicilar");

            if (response.Body != "null")
            {
                var kullanicilar = response.ResultAs<Dictionary<string, kullanici>>();

                // 🔴 KRİTİK KONTROL
                if (kullanicilar != null)
                {
                    foreach (var item in kullanicilar)
                    {
                        if (item.Value.KullaniciAdi == txtYeniKullanici.Text)
                        {
                            MessageBox.Show("Bu kullanıcı adı zaten alınmış");
                            return;
                        }
                    }
                }
            }

            kullanici yeniKullanici = new kullanici()
            {
                Ad = txtAd.Text,
                Soyad = txtSoyad.Text,
                KullaniciAdi = txtYeniKullanici.Text,
                Sifre = txtYeniSifre.Text
            };

            client.Push("kullanicilar", yeniKullanici);

            MessageBox.Show("Kayıt başarılı");

            TextBoxTemizle();

            void TextBoxTemizle()
            {
                txtAd.Clear();
                txtSoyad.Clear();
                txtYeniKullanici.Clear();
                txtYeniSifre.Clear();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}

