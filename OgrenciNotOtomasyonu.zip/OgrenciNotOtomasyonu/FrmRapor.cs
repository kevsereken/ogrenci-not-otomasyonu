﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;

namespace OgrenciNotOtomasyonu
{
    public partial class Raporlama : Form
    {
        IFirebaseClient client;
        public Raporlama()
        {
            InitializeComponent();
            FirebaseBaglan();

        }
        void FirebaseBaglan()
        {
            IFirebaseConfig config = new FirebaseConfig
            {
                AuthSecret = "2h2vpH0S82QY4fbXL83Jd6neJlXGuD4fmSil297G",
                BasePath = "https://ogrenci-not-otomasyonu-default-rtdb.firebaseio.com/"

            };

            client = new FirebaseClient(config);
        }


        double DortlukSistem(string harfNotu)
        {
            switch (harfNotu)
            {
                case "AA": return 4.0;
                case "BA": return 3.5;
                case "BB": return 3.0;
                case "CB": return 2.5;
                case "CC": return 2.0;
                case "DC": return 1.5;
                case "DD": return 1.0;
                case "FD": return 0.5;
                default: return 0.0; // FF
            }
        }

        private void btnRaporOluştur_Click(object sender, EventArgs e)
        {
            lstRapor.Items.Clear();

            var response = client.Get("notlar");

            if (response.Body == "null")
            {
                MessageBox.Show("Kayıtlı not bulunamadı");
                return;
            }

            var notlar = response.ResultAs<Dictionary<string, NotBilgisi>>();

            string aktifOgrenci = "";
            double toplamDortluk = 0;
            int dersSayisi = 0;

            foreach (var item in notlar)
            {
                NotBilgisi n = item.Value;

                if (aktifOgrenci != n.OgrenciNo)
                {
                    if (dersSayisi > 0)
                    {
                        lstRapor.Items.Add(
                            ">> Genel Ortalama: " +
                            (toplamDortluk / dersSayisi).ToString("0.00")
                        );
                        lstRapor.Items.Add("");
                    }

                    toplamDortluk = 0;
                    dersSayisi = 0;

                    lstRapor.Items.Add("====================================");
                    lstRapor.Items.Add(
                        "Öğrenci: " + n.OgrenciAd + " (" + n.OgrenciNo + ")"
                    );
                    lstRapor.Items.Add("====================================");

                    aktifOgrenci = n.OgrenciNo;
                }

                double dortluk = DortlukSistem(n.HarfNotu);

                lstRapor.Items.Add(
                 "  Ders: " + n.DersAd +
                 " | Vize: " + n.Vize +
                 " | Final: " + n.Final +
                 " | Ort: " + n.ortalama.ToString("0.00") +
                 " | " + n.HarfNotu
                );


                toplamDortluk += dortluk;
                dersSayisi++;
            }

            if (dersSayisi > 0)
            {
                lstRapor.Items.Add(
                    ">> Genel Ortalama: " +
                    (toplamDortluk / dersSayisi).ToString("0.00")
                );
            }
        }

        private void lstRapor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Raporlama_Load(object sender, EventArgs e)
        {
            lstRapor.DrawMode = DrawMode.OwnerDrawFixed;
            lstRapor.DrawItem += lstRapor_DrawItem;
        }
        private void lstRapor_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            e.DrawBackground();

            string text = lstRapor.Items[e.Index].ToString();
            Brush brush = Brushes.Black;

            if (text.Contains(" | FF"))
                brush = Brushes.Red;

            e.Graphics.DrawString(
                text,
                e.Font,
                brush,
                e.Bounds
            );

            e.DrawFocusRectangle();
        }

        private void btnDersAnaliz_Click(object sender, EventArgs e)
        {
            lstDersAnaliz.Items.Clear();

            var response = client.Get("notlar");

            if (response.Body == "null")
            {
                MessageBox.Show("Not bulunamadı");
                return;
            }

            var notlar = response.ResultAs<Dictionary<string, NotBilgisi>>();

            var dersGruplari = notlar.Values
                                     .GroupBy(n => n.DersAd);

            foreach (var grup in dersGruplari)
            {
                string dersAdi = grup.Key;
                double ortalama = grup.Average(n => n.ortalama);
                int ogrenciSayisi = grup.Count();
                int ffSayisi = grup.Count(n => n.HarfNotu == "FF");

                // ⚠️ TEK Items.Add
                lstDersAnaliz.Items.Add(
                    dersAdi +
                    " | Ortalama: " + ortalama.ToString("0.00") +
                    " | Öğrenci: " + ogrenciSayisi +
                    " | FF: " + ffSayisi
                );
            }

        }


        }
    }

